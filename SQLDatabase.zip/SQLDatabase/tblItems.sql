﻿CREATE TABLE [dbo].[tblItems]
(
	[ItemID] INT NOT NULL PRIMARY KEY, 
    [Description] VARCHAR(50) NULL, 
    [Price] REAL NULL
)
