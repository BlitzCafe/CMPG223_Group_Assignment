﻿CREATE TABLE [dbo].[tblOrder_Details]
(
	[OrderID] INT NOT NULL PRIMARY KEY, 
    [ItemID] INT NULL, 
    [Quantity_Sold] INT NULL
)
